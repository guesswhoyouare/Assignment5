package iss.java.mail;

import javax.mail.MessagingException;
import java.io.IOException;

/**
 * Define a series of mail flow
 */
public interface IMailService {
	/**
     * Initialize and connect all of the mail server
     * @throws MessagingException Initialization or abnormal connections
     */
    public void connect() throws MessagingException;

    /**
     * Send a single message
     * @param recipient Recipient Email Address
     * @param subject Email Subject
     * @param content Email Content
     * @throws MessagingException Send mail error
     */
    public void send(String recipient, String subject, Object content) throws MessagingException;

    /**
     * Asks the server if there is new mail arrives
     * @return boolean,�� indicates whether there is a new message
     * @throws MessagingException  Asks a server error
     */
    public boolean listen() throws MessagingException;

    /**
     * Receive automatic reply content, and converted to a string
     * Note: Use any method you can think of to find reply message can be, not necessarily to use these two parameters
     * @param sender Automatic reply sender e-mail address
     * @param subject Automatic reply themes
     * @return Automatic reply content string
     * @throws MessagingException Mail abnormal inquiry
     * @throws IOException Download mail abnormal
     */
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException;
}
