package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

/**
 * Created by Mr.Wang on 2015/11/11.
 * use the TA's material
 * to achieve Authenticator class                      
 */
public class MailAuthenticator extends Authenticator {
	/**
     * Username (login mailbox)
     */ 
    private String username;
    /**
     * password
     */
    private String password;

    /**
     * Initialization email and password
     *
     * @param username mailbox
     * @param password password
     */
    public MailAuthenticator(String username, String password) {
        this.username = username;
        this.password = password;
    }

    String getPassword() {
        return password;
    }

    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(username, password);
    }

    String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
