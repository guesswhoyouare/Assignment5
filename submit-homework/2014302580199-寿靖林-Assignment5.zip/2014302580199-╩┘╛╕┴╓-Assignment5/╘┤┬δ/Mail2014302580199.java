package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class Mail2014302580199 implements IMailService{

	/**
     * Send e-mail props file 
     */
    private final transient Properties propsSend = System.getProperties();
    /**
     * Send E-mail session
     */
    private transient Session sessionSend;
    /**
     * Receive messages props�ļ�
     */
    private final transient Properties propsReceiver = System.getProperties();
    /**
     * Receiving mailbox session
     */
    private transient Session sessionReceiver;
    /**
     * Mail server login authentication
     */
    private transient MailAuthenticator authenticator;
    
	@Override
	public void connect() throws MessagingException {
		/**
	     * initialization SMTP��IMAP
	     *
	     * @param username
	     *                Send e-mail user name (address)
	     * @param password
	     *                password
	     * @param smtpHostName
	     *                SMTP Host address
	     */
		
		//��֤
		authenticator = new MailAuthenticator("s458051000@sina.com", "123456qq");
		//��ʼ��SMTP
		
		//��ʼ��props
		propsSend.put("mail.smtp.auth", "true");
		propsSend.put("mail.smtp.host", "smtp.sina.com");
		
		// ��������session
        sessionSend = Session.getInstance(propsSend,authenticator);
        
        //��ʼ��IMAP
        propsReceiver.put("mail.store.protocol", "imap");
        propsReceiver.put("mail.imap.host", "imap.sina.com");
        propsReceiver.put("mail.imap.port", "143");
        
        // ��������session
        sessionReceiver = Session.getInstance(propsReceiver,authenticator);
	}

	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		/**
	     * send email
	     *
	     * @param recipient
	     *                Recipient Email Address
	     * @param subject
	     *                Email Subject
	     * @param content
	     *                Email Content
	     * @throws MessagingException
	     */
		// ����mime�����ʼ�
        MimeMessage message = new MimeMessage(sessionSend);
        // ���÷�����
        message.setFrom(new InternetAddress(authenticator.getUsername()));
        // �����ռ���
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // ��������
        message.setSubject(subject);
        // �����ʼ�����
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // ����
        Transport.send(message); 
		
	}

	@Override
	public boolean listen() throws MessagingException {
		
	
		Store store = sessionReceiver.getStore();
		store.connect();
	
		// get the Folder
		Folder folder = store.getFolder("inbox");
		// open read only
		folder.open(Folder.READ_ONLY);
	
		
		int newMessageNumber = folder.getNewMessageCount();
		folder.close(false);
		store.close();
		if(newMessageNumber > 0){
			return true;
		}

		return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		
		Store store = sessionReceiver.getStore();
		store.connect();
		
		// get the Folder
		Folder folder = store.getFolder("inbox");
		// open read only
		folder.open(Folder.READ_ONLY);
		Message[] messages = folder.getMessages();
		int mailLength = messages.length;
		for(int i = 0;i < mailLength;i++){
			// �������
			String getSubject = messages[i].getSubject();
			if(getSubject.equals(subject)){
				return messages[i].getContent().toString();
			}
		}
		
		return null;
	}
	
}
